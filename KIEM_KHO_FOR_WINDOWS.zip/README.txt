═══════════════════════════════════════════════════════════════
   HUONG DAN SU DUNG TREN WINDOWS
═══════════════════════════════════════════════════════════════

CACH 1: CHAY TRUC TIEP (Can Python)
───────────────────────────────────────────────────────────────
1. Giai nen file zip nay
2. Double-click vao: CHAY_TREN_WINDOWS_SIMPLE.bat
3. Ung dung se tu dong cai dat va chay


CACH 2: TAO FILE .EXE (Can Python de build)
───────────────────────────────────────────────────────────────
1. Giai nen file zip nay
2. Double-click vao: BUILD_EXE_SIMPLE.bat
3. Doi qua trinh build hoan tat (co the mat vai phut)
4. File .exe se nam trong: dist\KiemKhoApp.exe
5. Copy file .exe sang may Windows khac de chay


CAC FILE CAN THIET
───────────────────────────────────────────────────────────────
✓ kiem_kho_app.py          - File chinh cua ung dung
✓ DuLieuDauVao.xlsx        - File du lieu Excel (BAT BUOC)
✓ Kiemke_template.xlsx      - File template Excel (de copy khi save)
✓ requirements.txt         - Danh sach thu vien can thiet
✓ BUILD_EXE_SIMPLE.bat     - De build file .exe (khuyen nghi)
✓ CHAY_TREN_WINDOWS_SIMPLE.bat - De chay truc tiep (khuyen nghi)


LUU Y
───────────────────────────────────────────────────────────────
- Neu chay truc tiep: Can cai Python truoc
- Neu build .exe: Can Python de build, sau do khong can Python de chay
- File DuLieuDauVao.xlsx phai cung thu muc voi file .bat hoac .exe
- File Kiemke_template.xlsx se duoc copy va doi ten khi bam SAVE

═══════════════════════════════════════════════════════════════
